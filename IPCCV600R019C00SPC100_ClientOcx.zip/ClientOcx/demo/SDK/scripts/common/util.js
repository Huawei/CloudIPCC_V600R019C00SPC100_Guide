var UTIL = new UTILClass();
function UTILClass() {
    this.GetFieldValueFromConfInfo = function (confInfo, field) {
        var fieldSplits = confInfo.split("|");
        for (var i = 0, fieldValue; fieldValue = fieldSplits[i++]; ) {
            //if find the field in it
            if (fieldValue.indexOf(field) >= 0) {
                var valueSplits = fieldValue.split("=");
                return valueSplits[1]; //the second part should be the value
            }
        }
        return "";
    }


    this.FormatCallID = function (ulTime, usDsn, ucHandle, ucServer) {
        var usDsnAfterCount = (usDsn * 1).toString(2)
        var usDsnLength = usDsnAfterCount.length
        for (var i = 0; i < (16 - usDsnLength); i++) {
            usDsnAfterCount = "0" + usDsnAfterCount
        }

        var ucHandleAfterCount = (ucHandle * 1).toString(2)
        var ucHandleLength = ucHandleAfterCount.length
        for (var i = 0; i < (8 - ucHandleLength); i++) {
            ucHandleAfterCount = "0" + ucHandleAfterCount
        }

        var ucServerAfterCount = (ucServer * 1).toString(2)
        var ucServerLength = ucServerAfterCount.length
        for (var i = 0; i < (8 - ucServerLength); i++) {
            ucServerAfterCount = "0" + ucServerAfterCount
        }

        var numberString = ucServerAfterCount + ucHandleAfterCount + usDsnAfterCount;
        var realNumber = parseInt(numberString, 2);

        var _CallID = ulTime + "-" + realNumber;

        return _CallID;
    }

    this.CheckIsNumber = function (strNumber) {
		if (strNumber === undefined || strNumber === null || strNumber === ""){
			return false;
		}
        var reg = new RegExp("^[0-9]*$");
        return reg.test(strNumber);
    }

    this.isInArray = function (arr, val)
    {    
        var i, iLen;    
        if(!(arr instanceof Array) || arr.length === 0)
        {        
            return false;    
        }    
        if(typeof Array.prototype.indexOf === 'function')
        {        
            return !!~arr.indexOf(val)    
        }    
        for(i = 0, iLen = arr.length; i < iLen; i++)
        {        
            if(val === arr[i])
            {            
                return true;        
            }    
        }    
        return false;
    }
}