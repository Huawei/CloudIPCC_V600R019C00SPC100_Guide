// ICSClient Ocx Event Handle
// Copyright © Huawei Technologies Co., Ltd. 2015. All rights reserved.

Event.ICSClientOcx = {
    ICSLoginSuccEvent: function (sEventInfo) {
        //set login status
        ICSClientState.SetLoginSuccess();
    },
    ICSLogoutSuccEvent: function (sEventInfo) {
        //set logout status
        ICSClientState.SetLogoutSuccess();
    },
    ICSTalkConnectedEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);

        //if the connected call media type is webchat
        if (obj.event.content.mediaType === 1) {
            ICSClientState.BeginWebChat(obj.event.content.callId, obj.event.content.uvid);
        }
        //if the connected call media type is clickcal
        if (obj.event.content.mediaType === 2) {
            ICSClientState.BeginClickCall(obj.event.content.callId, obj.event.content.uvid, obj.event.content.clickToDial);
        }
        //if the connected call media type is callback
        if (obj.event.content.mediaType === 4) {
            ICSClientState.BeginCallBack(obj.event.content.callId, obj.event.content.uvid);
        }
		//if the connected call media type is vccall
        if (obj.event.content.mediaType === 22) {
            ICSClientState.BeginVCCall(obj.event.content.callId, obj.event.content.uvid);
			//for the convienice copy the accessNumber to clipboard
			window.clipboardData.setData("Text",obj.event.content.vcConfInfo.accessNumber);
        }
    },
    ICSTalkReleaseEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);
        //if the connected call media type is webchat
        if (obj.event.content.mediaType === 1) {
            ICSClientState.EndWebChat();
        }
        //if the connected call media type is clickcal
        if (obj.event.content.mediaType === 2) {
            ICSClientState.EndClickCall();
        }
        //if the connected call media type is callback
        if (obj.event.content.mediaType === 4) {
            ICSClientState.EndCallBack();
        }
		
		//if the connected call media type is vccall
        if (obj.event.content.mediaType === 22) {
            ICSClientState.EndVCCall();
        }
    },
    ICSCallQueueEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);
        //if the connected call media type is webchat
        if (obj.event.content.mediaType === 1) {
            ICSClientState.BeginWebChatQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
        //if the connected call media type is clickcal
        if (obj.event.content.mediaType === 2) {
            ICSClientState.BeginClickCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
        //if the connected call media type is callback
        if (obj.event.content.mediaType === 4) {
            ICSClientState.BeginCallBackQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
		//if the connected call media type is vccall
        if (obj.event.content.mediaType === 22) {
            ICSClientState.BeginVCCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
    },
    ICSCallQueueTimeoutEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);
        //if the connected call media type is webchat
        if (obj.event.content.mediaType === 1) {
            ICSClientState.EndWebChatQueueing(obj.event.content.callId, obj.event.content.uvid);
        }

        //if the connected call media type is clickcal
        if (obj.event.content.mediaType === 2) {
            ICSClientState.EndClickCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }

        //if the connected call media type is callback
        if (obj.event.content.mediaType === 4) {
            ICSClientState.EndCallBackQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
		
		//if the connected call media type is vccall
        if (obj.event.content.mediaType === 22) {
            ICSClientState.EndVCCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
    },
    ICSCallQueueCancelEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);
        //if the connected call media type is webchat
        if (obj.event.content.mediaType === 1) {
            ICSClientState.EndWebChatQueueing(obj.event.content.callId, obj.event.content.uvid);
        }

        //if the connected call media type is clickcal
        if (obj.event.content.mediaType === 2) {
            ICSClientState.EndClickCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }

        //if the connected call media type is callback
        if (obj.event.content.mediaType === 4) {
            ICSClientState.EndCallBackQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
		
		//if the connected call media type is vccall
        if (obj.event.content.mediaType === 22) {
            ICSClientState.EndVCCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
    },
    ICSCallFailedEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);
        //if the connected call media type is webchat
        if (obj.event.content.mediaType === 1) {
            ICSClientState.EndWebChatQueueing(obj.event.content.callId, obj.event.content.uvid);
        }

        //if the connected call media type is clickcal
        if (obj.event.content.mediaType === 2) {
            ICSClientState.EndClickCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }

        //if the connected call media type is callback
        if (obj.event.content.mediaType === 4) {
            ICSClientState.EndCallBackQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
		
		//if the connected call media type is callback
        if (obj.event.content.mediaType === 22) {
            ICSClientState.EndVCCallQueueing(obj.event.content.callId, obj.event.content.uvid);
        }
    },
    ICSCallTransferEvent: function (sEventInfo) {

    },
    ICSSendTextMsgSuccEvent: function (sEventInfo) {

    },
    ICSSendTextMsgFailedEvent: function (sEventInfo) {

    },
    ICSTextMsgArrivedEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);
        var sender = obj.event.content.sender;
        var content = obj.event.content.chatContent;
        ICSClientState.ReceiveChatContent(sender, content);
    },
    PrepareJoinMeetingEvent: function (sEventInfo) {
        var obj = JSON.parse(sEventInfo);
        ICSClientUI.UpdateWhenPrepareJoinMeeting(obj.event.content.confInfo);
    },
    TerminateMeetingEvent: function (sEventInfo) {

    },
    MeetingMemberStateEvent: function (sEventInfo) {

    }

}