﻿// language string definition file
// Copyright Huawei Technologies Co., Ltd. 2016. All rights reserved.
/*
 * this file defines the language strings of diference language , 
 * the LangugePageClass has a public interface GetLanguagePage which returns the language string define page of specified language for self attributed  element. 
 *
 * Notice:
 * To Add a new language you need to as following
 * 1. In the LANGUGE_SUPPORT object , add a new member like LANGUAGE_SUPPORT_XXX:"XXX", NOTE That the javascript object members sperated by ","
 * 2. Copy the Language.English object definition, changes to Languge.XXX . Modify the member value to the string of specified string for language XXX
 * 3. In the GetLanguagePage method of LanguagePageClass, add an else if branch which enables the function to return the languagepage of specified language xxx.
 * 4. Done.
 */
//language supported  
LANGUAGE_SUPPORT = {
	LANGUAGE_SUPPORT_CHINESE:"Chinese",
	LANGUAGE_SUPPORT_ENGLISH:"English"
}

//LanguagePageClass
function LanguagePageClass()
{
	// function
	// desc: the function reture the language string define page for specified language
	// params：
	// [IN] lan : string of language
	// return： void
	this.GetLanguagePage = function(language){
		if (language === LANGUAGE_SUPPORT.LANGUAGE_SUPPORT_CHINESE){
			return LanguageString.Chinese;
		}
		else if (language === LANGUAGE_SUPPORT.LANGUAGE_SUPPORT_ENGLISH){
			return LanguageString.English;
		}
		else{
			return LanguageString.English;
		}
	}
}

var LanguageString = {};
LanguageString.Chinese = {
	I18N_AGENTDIALOG_CALLER_NUMBER:"主叫号码",
    I18N_AGENTDIALOG_CALLED_NUMBER:"被叫号码",
    I18N_AGENTDIALOG_WORK_NO:"工号",
    I18N_AGENTDIALOG_ENTER_DTMF:"输入拨出号码",
    I18N_AGENTDIALOG_SET_CALL_DATA:"设置随路数据",
    I18N_AGENTDIALOG_TRANSFER_TYPE:"转移类型",
    I18N_AGENTDIALOG_SKILL:"技能",
    I18N_AGENTDIALOG_AGENT:"座席",
    I18N_AGENTDIALOG_IVR:"自动语音",
    I18N_AGENTDIALOG_EXTERNAL_PHONE:"外部号码",
    I18N_AGENTDIALOG_TRANSFER_TARGET:"转移目标",
    I18N_AGENTDIALOG_TRANSFER_MODE:"转移模式",
    I18N_AGENTDIALOG_HELP_TYPE:"求助类型",
    I18N_AGENTDIALOG_HELP_MODE:"求助模式",
    I18N_AGENTDIALOG_TWO_PARTY:"两方求助",
    I18N_AGENTDIALOG_THREE_PARTY:"三方求助",
    I18N_AGENTDIALOG_HELP_WORKNO:"求助工号",
    I18N_AGENTDIALOG_HELP_SKILL:"求助技能",
    I18N_AGENTDIALOG_REST_TIME_IN_SECS:"休息时间(秒)",
    I18N_AGENTDIALOG_BUSY_CAUSE:"示忙原因",
    I18N_AGENTDIALOG_OPERATE_TYPE:"操作类型",
    I18N_AGENTDIALOG_REQUEST:"请求",
    I18N_AGENTDIALOG_INVITE:"邀请",
    I18N_AGENTDIALOG_AGENT_NUMBER:"座席个数",
    I18N_AGENTDIALOG_AGENT_LIST:"座席列表",
	I18N_AGENTDIALOG_BLIND_TRANSFER:"释放转",
	I18N_AGENTDIALOG_WARM_TRANSFER:"成功转",
	I18N_AGENTDIALOG_SPECIFIED_TRANSFER:"指定转",
	I18N_AGENTDIALOG_BLOCKED_TRANSFER:"挂起转",
	I18N_AGENTDIALOG_BRIDGED_TRANSFER:"通话转",
	I18N_AGENTDIALOG_THREE_PARTY_TRANSFER:"三方转",
	I18N_AGENTDIALOG_OLDPWD:"旧密码",
	I18N_AGENTDIALOG_NEWPWD:"新密码",
	I18N_AGENTDIALOG_CONFIRMPWD:"确认密码"
}
LanguageString.English = {
	I18N_AGENTDIALOG_CALLER_NUMBER:"Calling Number",
    I18N_AGENTDIALOG_CALLED_NUMBER:"Called Number",
    I18N_AGENTDIALOG_WORK_NO:"Work ID",
    I18N_AGENTDIALOG_ENTER_DTMF:"Enter dial number",
    I18N_AGENTDIALOG_SET_CALL_DATA:"Set call data",
    I18N_AGENTDIALOG_TRANSFER_TYPE:"Transfer type",
    I18N_AGENTDIALOG_SKILL:"Skill",
    I18N_AGENTDIALOG_AGENT:"Agent",
    I18N_AGENTDIALOG_IVR:"IVR",
    I18N_AGENTDIALOG_EXTERNAL_PHONE:"External Number",
    I18N_AGENTDIALOG_TRANSFER_TARGET:"Transferred to",
    I18N_AGENTDIALOG_TRANSFER_MODE:"Transfer Mode",
    I18N_AGENTDIALOG_HELP_TYPE:"Help Type",
    I18N_AGENTDIALOG_HELP_MODE:"Help Mode",
    I18N_AGENTDIALOG_TWO_PARTY:"Two-party",
    I18N_AGENTDIALOG_THREE_PARTY:"Three-party",
    I18N_AGENTDIALOG_HELP_WORKNO:"Agent for Help",
    I18N_AGENTDIALOG_HELP_SKILL:"Skill Queue for Help",
    I18N_AGENTDIALOG_REST_TIME_IN_SECS:"Resting Duration (s)",
    I18N_AGENTDIALOG_BUSY_CAUSE:"Busy Cause",
    I18N_AGENTDIALOG_OPERATE_TYPE:"Operation Type",
    I18N_AGENTDIALOG_REQUEST:"Request",
    I18N_AGENTDIALOG_INVITE:"Invite",
    I18N_AGENTDIALOG_AGENT_NUMBER:"Number of Agents",
    I18N_AGENTDIALOG_AGENT_LIST:"Agent List",
	I18N_AGENTDIALOG_BLIND_TRANSFER:"Blind Transfer",
	I18N_AGENTDIALOG_WARM_TRANSFER:"Warm Transfer",
	I18N_AGENTDIALOG_SPECIFIED_TRANSFER:"Specified Transfer",
	I18N_AGENTDIALOG_BLOCKED_TRANSFER:"Blocked Transfer",
	I18N_AGENTDIALOG_BRIDGED_TRANSFER:"Bridged Transfer",
	I18N_AGENTDIALOG_THREE_PARTY_TRANSFER:"Three-Party Transfer",
	I18N_AGENTDIALOG_OLDPWD:"Old Pwd",
	I18N_AGENTDIALOG_NEWPWD:"New Pwd",
	I18N_AGENTDIALOG_CONFIRMPWD:"Confirm Pwd"
}