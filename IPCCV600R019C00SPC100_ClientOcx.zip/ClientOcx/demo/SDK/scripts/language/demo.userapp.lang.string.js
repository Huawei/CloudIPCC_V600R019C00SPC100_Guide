﻿// language string definition file
// Copyright Huawei Technologies Co., Ltd. 2016. All rights reserved.
/*
 * this file defines the language strings of diference language , 
 * the LangugePageClass has a public interface GetLanguagePage which returns the language string define page of specified language for self attributed  element. 
 *
 * Notice:
 * To Add a new language you need to as following
 * 1. In the LANGUGE_SUPPORT object , add a new member like LANGUAGE_SUPPORT_XXX:"XXX", NOTE That the javascript object members sperated by ","
 * 2. Copy the Language.English object definition, changes to Languge.XXX . Modify the member value to the string of specified string for language XXX
 * 3. In the GetLanguagePage method of LanguagePageClass, add an else if branch which enables the function to return the languagepage of specified language xxx.
 * 4. Done.
 */
//language supported  
LANGUAGE_SUPPORT = {
	LANGUAGE_SUPPORT_CHINESE:"Chinese",
	LANGUAGE_SUPPORT_ENGLISH:"English"
}

//LanguagePageClass
function LanguagePageClass()
{
	// function
	// desc: the function reture the language string define page for specified language
	// params：
	// [IN] lan : string of language
	// return： void
	this.GetLanguagePage = function(language){
		if (language === LANGUAGE_SUPPORT.LANGUAGE_SUPPORT_CHINESE){
			return LanguageString.Chinese;
		}
		else if (language === LANGUAGE_SUPPORT.LANGUAGE_SUPPORT_ENGLISH){
			return LanguageString.English;
		}
		else{
			return LanguageString.English;
		}
	}
}

var LanguageString = {};
LanguageString.Chinese = {
	I18N_USERAPPDEMO_CO_HUAWEI:"华为技术有限公司",
	I18N_USERAPPDEMO_INITIALIZE_INTERFACE:"初始化接口",
	I18N_USERAPPDEMO_USER_NAME:"用户名",
	I18N_USERAPPDEMO_CURRENT_STATE:"当前状态",
	I18N_USERAPPDEMO_PHONE_STATE:"话机状态",
	I18N_USERAPPDEMO_LOGIN:"登录",
	I18N_USERAPPDEMO_CALL_LOGOUT:"登出",
	I18N_USERAPPDEMO_CALL_RELATED:"呼叫相关",
	I18N_USERAPPDEMO_VERIFYCODE:"验证码",
	I18N_USERAPPDEMO_UPDATEVERIFYCODE:"更新验证码",
	I18N_USERAPPDEMO_GETVERIFYCODE:"获取验证码",
	I18N_USERAPPDEMO_MEDIATYPE:"媒体类型",
	I18N_USERAPPDEMO_WEBCHAT:"1-文字交谈",
	I18N_USERAPPDEMO_VOICECALL:"2-点击通话",
	I18N_USERAPPDEMO_CALLBACK:"4-电话回呼",
	I18N_USERAPPDEMO_VCCALL:"22-智真呼叫",
	I18N_USERAPPDEMO_ACCESSCODE:"接入码",
	I18N_USERAPPDEMO_CALL:"呼叫",
	I18N_USERAPPDEMO_RELEASE:"释放",
	I18N_USERAPPDEMO_CANCEL_QUEUE:"取消排队",
	I18N_USERAPPDEMO_MULTIMEDIA_RELATED:"多媒体相关",
	I18N_USERAPPDEMO_CONFERENCE_MEMBER:"会议成员",
	I18N_USERAPPDEMO_CREATE_MEETING:"创建会议",
	I18N_USERAPPDEMO_RELEASE_MEETING:"结束会议",
	I18N_USERAPPDEMO_CHOOSE_WINDOW:"选择窗口",
	I18N_USERAPPDEMO_WIDTH:"宽度",
	I18N_USERAPPDEMO_HEIGHT:"高度",
	I18N_USERAPPDEMO_SHOW_WINDOW:"显示窗口",
	I18N_USERAPPDEMO_OPEN_LOCAL_VIDEO:"打开本地视频",
	I18N_USERAPPDEMO_CLOSE_LOCAL_VIDEO:"关闭本地视频",
	I18N_USERAPPDEMO_SETVIDEOPARAM:"设置视频参数",
	I18N_USERAPPDEMO_START_DESKTOP_SHARE:"开始桌面共享",
	I18N_USERAPPDEMO_STOP_DESKTOP_SHARE:"结束桌面共享",
	I18N_USERAPPDEMO_ALLOW_REMOTE_CTRL:"远程控制授权",
	I18N_USERAPPDEMO_STOP_REMOTE_CTRL:"结束远程控制",
	I18N_USERAPPDEMO_IO_RELATED:"IO 相关",
	I18N_USERAPPDEMO_SEND_FILE:"发送文件",
	I18N_USERAPPDEMO_CANCEL_SEND:"取消发送",
	I18N_USERAPPDEMO_FILENAME:"文件名",
	I18N_USERAPPDEMO_SAVE_FILE:"保存文件",
	I18N_USERAPPDEMO_RECEIVE_FILE:"接收文件",
	I18N_USERAPPDEMO_CANCEL_RECEIVE:"取消接收",
	I18N_USERAPPDEMO_WEBCHAT_RELATED:"文字交谈相关",
	I18N_USERAPPDEMO_MESSAGE:"消息",
	I18N_USERAPPDEMO_SEND_MESSAGE:"发送消息",
	I18N_USERAPPDEMO_CLEAR_CHAT_HISTORY:"清除聊天历史",
	I18N_USERAPPDEMO_OCX_TYPE:"Ocx类型",
	I18N_USERAPPDEMO_CONFERENCE_CONTROL:"ConferenceOCX",
	I18N_USERAPPDEMO_VOICE_CONTROL:"VoiceOCX",
	I18N_USERAPPDEMO_ICSCLIENT_CONTROL:"ICSClientOCX",
	I18N_USERAPPDEMO_ERRORCODE:"错误码",
	I18N_USERAPPDEMO_QUERY_ERRORCODE:"查询错误码",
	I18N_USERAPPDEMO_LOG:"日志",
	I18N_USERAPPDEMO_SAVE_PAGE_LOG:"保存页面日志(c:\eMedia)"
}
LanguageString.English = {
	I18N_USERAPPDEMO_CO_HUAWEI:"Huawei Technologies Co., Ltd.",
	I18N_USERAPPDEMO_INITIALIZE_INTERFACE:"Initialize Interface",
	I18N_USERAPPDEMO_USER_NAME:"UserName",
	I18N_USERAPPDEMO_CURRENT_STATE:"CurrentStatus",
	I18N_USERAPPDEMO_PHONE_STATE:"PhoneStatus",
	I18N_USERAPPDEMO_LOGIN:"Login",
	I18N_USERAPPDEMO_CALL_LOGOUT:"Logout",
	I18N_USERAPPDEMO_CALL_RELATED:"Call Related",
	I18N_USERAPPDEMO_MEDIATYPE:"Media Type",
	I18N_USERAPPDEMO_WEBCHAT:"1-WebChat",
	I18N_USERAPPDEMO_VOICECALL:"2-CTD",
	I18N_USERAPPDEMO_CALLBACK:"4-CallBack",
	I18N_USERAPPDEMO_VCCALL:"22-VCCall",
	I18N_USERAPPDEMO_ACCESSCODE:"AccessCode",
	I18N_USERAPPDEMO_CALL:"Call",
	I18N_USERAPPDEMO_RELEASE:"Release",
	I18N_USERAPPDEMO_CANCEL_QUEUE:"Cancel Queuing",
	I18N_USERAPPDEMO_MULTIMEDIA_RELATED:"Multimedia Related",
	I18N_USERAPPDEMO_CONFERENCE_MEMBER:"Conference Participant",
	I18N_USERAPPDEMO_CREATE_MEETING:"Create Conference",
	I18N_USERAPPDEMO_RELEASE_MEETING:"End Conference",
	I18N_USERAPPDEMO_CHOOSE_WINDOW:"Choose Window",
	I18N_USERAPPDEMO_WIDTH:"Width",
	I18N_USERAPPDEMO_HEIGHT:"Height",
	I18N_USERAPPDEMO_SHOW_WINDOW:"Show Window",
	I18N_USERAPPDEMO_OPEN_LOCAL_VIDEO:"OpenLocalVideo",
	I18N_USERAPPDEMO_CLOSE_LOCAL_VIDEO:"CloseLocalVideo",
	I18N_USERAPPDEMO_SETVIDEOPARAM:"SetVideoParam",
	I18N_USERAPPDEMO_START_DESKTOP_SHARE:"Start DesktopShare",
	I18N_USERAPPDEMO_STOP_DESKTOP_SHARE:"Stop DesktopShare",
	I18N_USERAPPDEMO_ALLOW_REMOTE_CTRL:"Authorize RemoteCtrl",
	I18N_USERAPPDEMO_STOP_REMOTE_CTRL:"Revoke RemoteCtrl",
	I18N_USERAPPDEMO_IO_RELATED:"IO-Related",
	I18N_USERAPPDEMO_SEND_FILE:"Send File",
	I18N_USERAPPDEMO_CANCEL_SEND:"Cancel Sending",
	I18N_USERAPPDEMO_FILENAME:"File Name",
	I18N_USERAPPDEMO_SAVE_FILE:"Saved as",
	I18N_USERAPPDEMO_RECEIVE_FILE:"ReceiveFile",
	I18N_USERAPPDEMO_CANCEL_RECEIVE:"Cancel Receiving",
	I18N_USERAPPDEMO_WEBCHAT_RELATED:"WebChat-related",
	I18N_USERAPPDEMO_MESSAGE:"Message",
	I18N_USERAPPDEMO_SEND_MESSAGE:"SendMessage",
	I18N_USERAPPDEMO_CLEAR_CHAT_HISTORY:"ClearChatHistory",
	I18N_USERAPPDEMO_OCX_TYPE:"OcxType",
	I18N_USERAPPDEMO_CONFERENCE_CONTROL:"ConferenceOCX",
	I18N_USERAPPDEMO_VOICE_CONTROL:"VoiceOCX",
	I18N_USERAPPDEMO_ICSCLIENT_CONTROL:"ICSClientOCX",
	I18N_USERAPPDEMO_ERRORCODE:"ErrorCode",
	I18N_USERAPPDEMO_QUERY_ERRORCODE:"QueryErrorCode",
	I18N_USERAPPDEMO_LOG:"LOG",
	I18N_USERAPPDEMO_SAVE_PAGE_LOG:"Save Page Log(c:\eMedia)"
}