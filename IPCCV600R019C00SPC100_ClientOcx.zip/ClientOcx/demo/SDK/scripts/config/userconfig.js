var UserConfig = {}
UserConfig.Common = {
    "Language":"Chinese", //please see /language/demo.userapp.lang.string.js to see what language the demo supports
    "LogLevel":"Debug" //Debug, Info, Warn, Error
}

UserConfig.ICSClient = {
	"icsgatewayIp": "127.0.0.1",
	"icsgatewayPort": "8243",
	"icsgatewayName": "icsgateway",
	"VdnID":"1",
	"sslEnable":true
}

UserConfig.Voice = 
{
	"SipServerIP":"127.0.0.1",
	"SipServerPort":"5060",
	"BackSipServerIP":"",
	"BackSipServerPort":"",
	"LocalIP":"127.0.0.1",
	"LocalSipPort":"7061",
	"LocalAudioPort": "7062",
    "AnnonymousCard":"AnonymousCard"
}

