function GetValueFromElement(eleName) 
{
    var v = document.getElementById(eleNames).value;
    return v;   
}
