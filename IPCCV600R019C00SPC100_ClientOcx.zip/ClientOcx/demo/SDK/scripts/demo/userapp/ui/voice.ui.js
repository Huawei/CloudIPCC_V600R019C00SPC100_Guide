//notice
/*
 *	voiceui must implement following interface
 *  UpdateVoicePhoneState
 */
//VoiceUIClass constructor
function VoiceUIClass() {
    
}

//VoiceUIClass methods define
VoiceUIClass.prototype = {
    UpdateVoicePhoneState: function () {
        if (VoicePhoneState.GetVoiceTalkingState() === VOICE_PHONE_TALKING_STATE.VOICE_PHONE_TALKING) {
            document.getElementById("UserAppDemo.PhoneStatus").innerHTML = "<font color='green'>" + VoicePhoneState.GetRegisteredPhoneNumber() + ":" + "Talking-" + VoicePhoneState.GetCallingPhoneNumber() + "</font>";
        }
        else if (VoicePhoneState.GetVoiceTalkingState() === VOICE_PHONE_TALKING_STATE.VOICE_PHONE_ALERTING) {
            document.getElementById("UserAppDemo.PhoneStatus").innerHTML = "<font color='alerting'>" + VoicePhoneState.GetRegisteredPhoneNumber() + ":" + "Alerting-" + VoicePhoneState.GetCallingPhoneNumber() + "</font>";
        }
        else if (VoicePhoneState.GetVoiceTalkingState() === VOICE_PHONE_TALKING_STATE.VOICE_PHONE_RELEASED) {
            if (VoicePhoneState.GetVoiceRegisterState() === VOICE_PHONE_REGISTER_STATE.VOICE_PHONE_UNREGISTERED) {
                document.getElementById("UserAppDemo.PhoneStatus").innerHTML = "<font color='black'>" + 'unregistered' + "</font>";
            }
            else{
                document.getElementById("UserAppDemo.PhoneStatus").innerHTML = "<font color='blue'>" + "registered" + "</font>";
            }
        }
    }
}