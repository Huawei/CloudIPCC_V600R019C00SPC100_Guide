//notice
/*
*	ConferenceUI must implement following interface
*   UpdateWhenConfMemberEntered
*   UpdateWhenConfMemberLeaved
*   UpdateWhenConfMeetingTeminated
*   UpdateWhenVideoDeviceOpened
*   UpdateWhenVideoDeviceClosed
*/
//ConferenceUIClass constructor
function ConferenceUIClass() {
    this.AddToConfMemberList = function (userID) {
        var userLink = "<a href=\"#\" title=\"" + userID + "\" id=\"user_" + userID + "\">" + userID + " </a>";
        document.getElementById("AgentAppDemo.Conference.UserList").innerHTML += userLink;
    }
    this.RemoveFromConfMemberList = function (userID) {
        var elem = document.getElementById('user_' + userID);
        if (elem) {
            elem.parentNode.removeChild(elem);
        }
    }
    this.ClearConfMemberList = function () {
        document.getElementById("AgentAppDemo.Conference.UserList").innerHTML = "";
    }
}

//VoiceUIClass methods define
ConferenceUIClass.prototype = {
    UpdateWhenConfMemberEntered: function (userID, userRole) {
        this.AddToConfMemberList(userID);
    },
    UpdateWhenConfMemberLeaved: function (userID) {
        this.RemoveFromConfMemberList(userID);
        if (ConferenceState.IsSelfUser(userID)) {
            AgentExcute("StopMultimediaConf", ConferenceState.GetCurrentJoinedConfID());
            WndUiUI.RemoveWindowList();
            this.ClearConfMemberList();
            ConferenceState.RemoveAllConfMembers();
            ConferenceState.SetCurrentJoinedConfID("");
            ConferenceState.SetJoinedConfInfo("");
            ConferenceState.RemoveAllConfVideoDevices();
			document.getElementById('AgentAppDemo.SetVideoParam').disabled = true;
        }
    },
    UpdateWhenJoinConfSuccess: function (resultCode) {
        AgentExcute("JoinMultimediaConfResponse", ConferenceState.GetCurrentJoinedConfID(), 0, resultCode);
        AgentAppDemoExcute("CreateDesktopShareWindow");
		document.getElementById("AgentAppDemo.OpenLocalVideo").style.display = "inline";
		document.getElementById("AgentAppDemo.CloseLocalVideo").style.display = "none";
		document.getElementById("AgentAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("AgentAppDemo.StopRemoteCtrl").style.display = "none";
		document.getElementById('AgentAppDemo.SetVideoParam').disabled = true;
		UserState.SetIsLocalVideoOpened(false);
    },
    UpdateWhenJoinConfFailed: function (resultCode) {
        AgentExcute("JoinMultimediaConfResponse", ConferenceState.GetCurrentJoinedConfID(), 1, resultCode);
    },
    UpdateWhenConfMeetingTeminatedSuccess: function (confID) {
        this.ClearConfMemberList();
        WndUiUI.RemoveWindowList();
        AgentExcute("StopMultimediaConf", confID);
        ConferenceState.RemoveAllConfMembers();
        ConferenceState.SetCurrentJoinedConfID("");
        ConferenceState.SetJoinedConfInfo("");
        ConferenceState.RemoveAllConfVideoDevices();
		document.getElementById("AgentAppDemo.OpenLocalVideo").style.display = "inline";
		document.getElementById("AgentAppDemo.CloseLocalVideo").style.display = "none";
		document.getElementById("AgentAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("AgentAppDemo.StopRemoteCtrl").style.display = "none";
		document.getElementById('AgentAppDemo.SetVideoParam').disabled = true;
    },
    UpdateWhenConfMeetingTeminatedFailed: function (confID) {
        //no need to do anything
    },
    UpdateWhenVideoDeviceOpened: function (userID, deviceID) {
        AgentAppDemoExcute("CreateVideoDeviceWindow", userID, deviceID);
        if (parseInt(userID) === ConferenceState.GetSelfUserID()) {
            UserState.SetIsLocalVideoOpened(true);
            document.getElementById("AgentAppDemo.OpenLocalVideo").style.display = "none";
			document.getElementById("AgentAppDemo.CloseLocalVideo").style.display = "inline";
            document.getElementById('AgentAppDemo.SetVideoParam').disabled = false;
        }
        if (parseInt(userID) === ConferenceState.GetTalkingUser()) {
        }
    },
    UpdateWhenVideoDeviceClosed: function (userID, deviceID) {
        var hwnd = 0;
        var wndList = WndUiState.GetWndList();
        for (var i = 0; i < wndList.length; i++) {
            if (wndList[i].title.indexOf(userID + "_" + deviceID) > 0) {
                hwnd = wndList[i].hwnd;
                break;
            }
        }

        if (hwnd === 0) {
            INFO_LOG_METHOD("ConferenceUI", " Warning!!!! close a video device ,but it is not in the list!");
        }

        AgentAppDemoExcute("CloseVideoDeviceWindow", userID, deviceID, hwnd);
        if (parseInt(userID) === ConferenceState.GetSelfUserID()) {
            UserState.SetIsLocalVideoOpened(false);
            document.getElementById("AgentAppDemo.OpenLocalVideo").style.display = "inline";
			document.getElementById("AgentAppDemo.CloseLocalVideo").style.display = "none";
            document.getElementById('AgentAppDemo.SetVideoParam').disabled = true;
        }
        if (parseInt(userID) === ConferenceState.GetTalkingUser()) {
        }
    },
    UpdateWhenFileArrived: function (fileHandle, fileName, fileSize) {
        document.getElementById('AgentAppDemo.ReceiveFile.FileHandle').value = fileHandle;
        document.getElementById('AgentAppDemo.ReceiveFile.FileName').value = fileName;
        document.getElementById('AgentAppDemo.ReceiveFile.FileName').style.backgroundColor = "yellow";
    },
    UpdateWhenFileTransRecvProgress: function (fileHandle, fileName, fileSize, fileProgress, senderId, resultCode) {
        document.getElementById('AgentAppDemo.Conference.FileTranRecvProgress').innerHTML = 'recv complete:' + fileProgress + '%;ResultCode:' + resultCode;

    },
    UpdateWhenFileTransSendProgress: function (fileHandle, fileName, fileSize, fileProgress, senderId, resultCode) {
        document.getElementById('AgentAppDemo.Conference.FileTranSendProgress').innerHTML = 'send complete:' + fileProgress + '%;ResultCode:' + resultCode;
        document.getElementById('AgentAppDemo.SendFile.FileHandle').value = fileHandle;
    },
    UpdateWhenFileTransSendOverSuccess: function (fileHandle, fileName, fileSize, senderId) {
        document.getElementById('AgentAppDemo.SendFile.FileHandle').value = fileHandle;
        document.getElementById('AgentAppDemo.Conference.FileTranSendProgress').innerHTML = 'send complete!';
    },
    UpdateWhenFileTransSendOverFailed: function (fileHandle, fileName, fileSize, senderId, resultCode) {
        document.getElementById('AgentAppDemo.SendFile.FileHandle').value = fileHandle;
        document.getElementById('AgentAppDemo.Conference.FileTranSendProgress').innerHTML = 'send failed!' + ';ResultCode:' + resultCode;
    },
    UpdateWhenFileTransRecvOverSuccess: function (fileHandle, fileName, fileSize, senderId) {
        document.getElementById('AgentAppDemo.ReceiveFile.FileHandle').value = '';
        document.getElementById('AgentAppDemo.ReceiveFile.FileName').value = '';
        document.getElementById('AgentAppDemo.ReceiveFile.FileName').style.backgroundColor = "white";
        document.getElementById('AgentAppDemo.Conference.FileTranRecvProgress').innerHTML = 'recv complete!';
    },
    UpdateWhenFileTransRecvOverFailed: function (fileHandle, fileName, fileSize, senderId, resultCode) {

        document.getElementById('AgentAppDemo.ReceiveFile.FileHandle').value = '';
        document.getElementById('AgentAppDemo.ReceiveFile.FileName').value = '';
        document.getElementById('AgentAppDemo.ReceiveFile.FileName').style.backgroundColor = "red";
        document.getElementById('AgentAppDemo.Conference.FileTranRecvProgress').innerHTML = 'recv failed!' + ';ResultCode:' + resultCode;
    },
    UpdateWhenDesktopShareSizeShow: function () {
        //when the other user start share screen, change the control state back
		document.getElementById("AgentAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("AgentAppDemo.StopRemoteCtrl").style.display = "none";
    },
	UpdateWhenSetOperationPrivilegeState: function(action, privilegeType, userId){
		if (privilegeType === "remotectl"){
			if (action === "delete")
			{
				if (parseInt(userId) !== ConferenceState.GetSelfUserID() && ConferenceState.GetIsSharingDesktop())
				{
					document.getElementById("AgentAppDemo.AllowRemoteCtrl").style.display = "inline";
					document.getElementById("AgentAppDemo.StopRemoteCtrl").style.display = "none";
				}
			}
			else if (action === "add"){
				if (parseInt(userId) !== ConferenceState.GetSelfUserID() && ConferenceState.GetIsSharingDesktop())
				{
					document.getElementById("AgentAppDemo.AllowRemoteCtrl").style.display = "none";
					document.getElementById("AgentAppDemo.StopRemoteCtrl").style.display = "inline";
				}
			}
		}
	},
	UpdateWhenStartShareScreenResult: function(resultCode){
		document.getElementById("AgentAppDemo.AllowRemoteCtrl").style.display = "inline";
		document.getElementById("AgentAppDemo.StopRemoteCtrl").style.display = "none";
	}
}