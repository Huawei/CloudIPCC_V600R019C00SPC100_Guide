function UserStateClass()
{
    this._withMeetingOption = false;
    this._webChatAccessCode = "";
    this._voiceCallAccessCode = "";
    this._selectedDeviceID = "";
    this._localVideoOpened = false;
	this.GetWithMeetingOption = function()
	{
		return this._withMeetingOption;
	}
	this.SetWithMeetingOption = function(option)
	{
		this._withMeetingOption = option;
    }
    this.GetWebChatAccessCode = function () {
        return this._webChatAccessCode;
    }
    this.SeWebChatAccessCode = function (option) {
        this._webChatAccessCode = option;
    }
    this.GetVoiceCallAccessCode = function () {
        return this._voiceCallAccessCode;
    }
    this.SetVoiceCallAccessCode = function (option) {
        this._voiceCallAccessCode = option;
    }
    this.GetSelectedVideoDevice = function () {
        return parseInt(this._selectedDeviceID);
    }
    this.SetSelectedVideoDevice = function (option) {
        this._selectedDeviceID = option;
    }
    this.GetIsLocalVideoOpened = function () {
        return this._localVideoOpened;
    }
    this.SetIsLocalVideoOpened = function (option) {
        this._localVideoOpened = option;
    }
}

